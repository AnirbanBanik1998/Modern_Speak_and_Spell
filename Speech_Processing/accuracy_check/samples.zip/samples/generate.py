import json, os
import pprint
# Generated voices.json with `aws polly describe-voices > voices.json`
with open('voices.json') as json_data:
    d = json.load(json_data)

with open("a.txt") as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
content = [x.strip() for x in content]

for e in  d["Voices"]:
    pprint.pprint(e["Name"])
    if not os.path.exists(e["Name"]):
        os.makedirs(e["Name"])
    for x in content:
        print("aws polly synthesize-speech \
        --output-format mp3 \
        --voice-id "+e["Name"]+" \
        --text \""+x+"\"\
        "+e["Name"]+"/"+x+".mp3")
        os.system("aws polly synthesize-speech \
        --output-format mp3 \
        --voice-id "+e["Name"]+" \
        --text \""+x+"\"\
        "+e["Name"]+"/"+x+".mp3")
